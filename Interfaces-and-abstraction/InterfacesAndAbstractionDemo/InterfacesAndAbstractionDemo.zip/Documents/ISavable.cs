﻿namespace InterfacesAndAbstractionDemo.Documents
{
    public interface ISavable
    {
        void SaveToFile(string fileName);
    }
}
