﻿namespace InterfacesAndAbstractionDemo.Documents
{
    public interface IPrintable
    {
        void Print();

        void PrintToPdf();
    }
}
