﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._3_Telephony
{
    interface IBrowsable
    {
        public void Browse();
    }
}
