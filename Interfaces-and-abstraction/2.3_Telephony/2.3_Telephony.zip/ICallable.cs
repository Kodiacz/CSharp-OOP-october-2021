﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._3_Telephony
{
    interface ICallable
    {
        public void Call();
    }
}
