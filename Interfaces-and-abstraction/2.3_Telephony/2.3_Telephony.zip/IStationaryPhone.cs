﻿namespace _2._3_Telephony
{
    public interface IStationaryPhone
    {
    }
}