﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._6FoodShortage
{
    public interface IBirthdateable
    {
        public string Birthdate { get; set; }
    }
}
