﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._6FoodShortage
{
    public interface IAgeable
    {
        public int Age { get; set; }
    }
}
