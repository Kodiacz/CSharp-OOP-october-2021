﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._6FoodShortage
{
    interface IGroupable
    {
        public string Group { get; set; }
    }
}
