﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var test = new Fish("torta", 25);
            Console.WriteLine(test.Grams);
            
        }
    }
}
